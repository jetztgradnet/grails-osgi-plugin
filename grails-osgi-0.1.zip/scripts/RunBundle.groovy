import org.ops4j.pax.runner.Run;

includeTargets << grailsScript("Init")
includeTargets << grailsScript("_GrailsWar")

target(main: "The description of the script goes here!") {
	runBundle()
}

target(runBundle: '''Package the application as OSGi bundle
	
	Examples: 
	grails run-bundle
	grails prod run-bundle
	''') {
	depends(checkVersion, war)

	Run.main(["--args=file:$osgiPluginDir/paxrunner-grails.profile", "scan-bundle:file:$warName"] as String[]);
}


setDefaultTarget(main)
